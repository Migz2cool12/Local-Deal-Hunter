const state={cat:"all",query:"",sort:"price",lat:null,lng:null,zip:null,deals:[]};

const sample=[
{id:1,cat:"grocery",item:"Dozen Eggs",store:"Sample local store",price:2.49,old:4.99,distance:null,saving:2.50,fresh:"Sample only"},
{id:2,cat:"grocery",item:"Whole Milk",store:"Sample local store",price:3.49,old:4.49,distance:null,saving:1,fresh:"Sample only"}
];

const $=s=>document.querySelector(s);
const money=n=>"$"+Number(n).toFixed(2);

function render(){
 let list=state.deals.filter(d=>(state.cat==="all"||d.cat===state.cat)&&(`${d.item} ${d.store}`.toLowerCase().includes(state.query.toLowerCase())));
 list.sort((a,b)=>state.sort==="distance"?(a.distance??999)-(b.distance??999):state.sort==="savings"?b.saving-a.saving:a.price-b.price);
 $("#resultCount").textContent=`${list.length} deal${list.length===1?"":"s"}`;
 $("#deals").innerHTML=list.length?list.map(d=>`<article class="card">
<div class="row"><span class="tag">${d.cat}</span><span>📍 ${d.distance==null?"—":d.distance.toFixed(1)+" mi"}</span></div>
<div class="price">${money(d.price)} ${d.old?`<span class="old">${money(d.old)}</span>`:""}</div>
${d.saving>0?`<span class="save">Save ${money(d.saving)}</span>`:""}
<div class="store">${escapeHtml(d.store)}</div><div class="meta">${escapeHtml(d.item)}</div>
<div class="fresh">${escapeHtml(d.fresh||"Price source")}</div><button onclick="saveDeal(${d.id})">♡ Save deal</button></article>`).join(""):`<div class="empty">No verified deals were returned for this search/area. Try another item or a larger search area.</div>`;
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function saveDeal(id){let a=JSON.parse(localStorage.getItem("savedDeals")||"[]");if(!a.includes(id)){a.push(id);localStorage.setItem("savedDeals",JSON.stringify(a));alert("Deal saved.")}else alert("Already saved.")}
window.saveDeal=saveDeal;

async function loadLiveGrocery(){
 if(!state.lat||!state.lng){state.deals=sample;$("#sourceStatus").textContent="Waiting for location. Sample deals are shown only as a fallback.";render();return;}
 // Nourish documents a public preview endpoint supporting lat/lng. The preview is intentionally used
 // without inventing an API key; production full catalog access can be added with a server-side key.
 const url=`https://mynourish.app/api/v1/public/prices?lat=${encodeURIComponent(state.lat)}&lng=${encodeURIComponent(state.lng)}`;
 try{
  const r=await fetch(url,{headers:{Accept:"application/json"}});
  if(!r.ok) throw new Error("source unavailable");
  const data=await r.json();
  const rows=[];
  for(const store of (data.stores||[])){
   for(const p of (store.prices||store.items||[])){
    const price=Number(p.price??p.current_price);
    if(!Number.isFinite(price)) continue;
    rows.push({id:crypto.randomUUID(),cat:"grocery",item:p.item||p.name||"Grocery item",store:store.name||store.store||"Nearby store",price,old:Number(p.regular_price??p.list_price)||null,distance:null,saving:Math.max(0,(Number(p.regular_price??p.list_price)||price)-price),fresh:p.scrapedAt||p.updatedAt||data.updatedAt?"Live source":"Live source"});
   }
  }
  state.deals=rows;
  $("#sourceStatus").textContent=rows.length?`🟢 Live grocery prices loaded for the detected area.`:"No live grocery coverage was returned for this area.";
  render();
 }catch(e){
  state.deals=[];
  $("#sourceStatus").textContent="Live grocery source could not be reached. No fake prices are shown.";
  render();
 }
}

function useLocation(){
 if(!navigator.geolocation){$("#locationStatus").textContent="This browser does not support location.";return}
 $("#locationStatus").textContent="📍 Getting your location…";
 navigator.geolocation.getCurrentPosition(async p=>{
  state.lat=p.coords.latitude;state.lng=p.coords.longitude;
  $("#locationStatus").textContent=`📍 Location enabled. Results are being filtered to your area.`;
  await loadLiveGrocery();
 },()=>{$("#locationStatus").textContent="Location permission was denied. Enable location to get area-specific prices."},{enableHighAccuracy:false,maximumAge:300000,timeout:10000});
}

$("#locBtn").onclick=useLocation;
$("#search").oninput=e=>{state.query=e.target.value;render()};
$("#sort").onchange=e=>{state.sort=e.target.value;render()};
document.querySelectorAll("#cats button").forEach(b=>b.onclick=()=>{document.querySelector(".cats .active").classList.remove("active");b.classList.add("active");state.cat=b.dataset.cat;render()});
render();
if("serviceWorker"in navigator)navigator.serviceWorker.register("sw.js").catch(()=>{});
